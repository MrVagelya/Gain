(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,13515,e=>{"use strict";let t,r;var n,i,o,a,s=e.i(43476),l=e.i(71645),u=e.i(75056),c=e.i(94800),f=e.i(48546),d=e.i(31067),m=e.i(90072);let p={uniforms:{tDiffuse:{value:null},h:{value:1/512}},vertexShader:`
      varying vec2 vUv;

      void main() {

        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

      }
  `,fragmentShader:`
    uniform sampler2D tDiffuse;
    uniform float h;

    varying vec2 vUv;

    void main() {

    	vec4 sum = vec4( 0.0 );

    	sum += texture2D( tDiffuse, vec2( vUv.x - 4.0 * h, vUv.y ) ) * 0.051;
    	sum += texture2D( tDiffuse, vec2( vUv.x - 3.0 * h, vUv.y ) ) * 0.0918;
    	sum += texture2D( tDiffuse, vec2( vUv.x - 2.0 * h, vUv.y ) ) * 0.12245;
    	sum += texture2D( tDiffuse, vec2( vUv.x - 1.0 * h, vUv.y ) ) * 0.1531;
    	sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y ) ) * 0.1633;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 1.0 * h, vUv.y ) ) * 0.1531;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 2.0 * h, vUv.y ) ) * 0.12245;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 3.0 * h, vUv.y ) ) * 0.0918;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 4.0 * h, vUv.y ) ) * 0.051;

    	gl_FragColor = sum;

    }
  `},h={uniforms:{tDiffuse:{value:null},v:{value:1/512}},vertexShader:`
    varying vec2 vUv;

    void main() {

      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

    }
  `,fragmentShader:`

  uniform sampler2D tDiffuse;
  uniform float v;

  varying vec2 vUv;

  void main() {

    vec4 sum = vec4( 0.0 );

    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 4.0 * v ) ) * 0.051;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 3.0 * v ) ) * 0.0918;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 2.0 * v ) ) * 0.12245;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 1.0 * v ) ) * 0.1531;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y ) ) * 0.1633;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 1.0 * v ) ) * 0.1531;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 2.0 * v ) ) * 0.12245;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 3.0 * v ) ) * 0.0918;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 4.0 * v ) ) * 0.051;

    gl_FragColor = sum;

  }
  `},v=l.forwardRef(({scale:e=10,frames:t=1/0,opacity:r=1,width:n=1,height:i=1,blur:o=1,near:a=0,far:s=10,resolution:u=512,smooth:v=!0,color:x="#000000",depthWrite:y=!1,renderOrder:g,...w},b)=>{let S,M,E=l.useRef(null),A=(0,f.useThree)(e=>e.scene),z=(0,f.useThree)(e=>e.gl),U=l.useRef(null);n*=Array.isArray(e)?e[0]:e||1,i*=Array.isArray(e)?e[1]:e||1;let[D,_,C,B,j,P,L]=l.useMemo(()=>{let e=new m.WebGLRenderTarget(u,u),t=new m.WebGLRenderTarget(u,u);t.texture.generateMipmaps=e.texture.generateMipmaps=!1;let r=new m.PlaneGeometry(n,i).rotateX(Math.PI/2),o=new m.Mesh(r),a=new m.MeshDepthMaterial;a.depthTest=a.depthWrite=!1,a.onBeforeCompile=e=>{e.uniforms={...e.uniforms,ucolor:{value:new m.Color(x)}},e.fragmentShader=e.fragmentShader.replace("void main() {",`uniform vec3 ucolor;
           void main() {
          `),e.fragmentShader=e.fragmentShader.replace("vec4( vec3( 1.0 - fragCoordZ ), opacity );","vec4( ucolor * fragCoordZ * 2.0, ( 1.0 - fragCoordZ ) * 1.0 );")};let s=new m.ShaderMaterial(p),l=new m.ShaderMaterial(h);return l.depthTest=s.depthTest=!1,[e,r,a,o,s,l,t]},[u,n,i,e,x]),V=e=>{B.visible=!0,B.material=j,j.uniforms.tDiffuse.value=D.texture,j.uniforms.h.value=e/256,z.setRenderTarget(L),z.render(B,U.current),B.material=P,P.uniforms.tDiffuse.value=L.texture,P.uniforms.v.value=e/256,z.setRenderTarget(D),z.render(B,U.current),B.visible=!1},O=0;return(0,c.useFrame)(()=>{U.current&&(t===1/0||O<t)&&(O++,S=A.background,M=A.overrideMaterial,E.current.visible=!1,A.background=null,A.overrideMaterial=C,z.setRenderTarget(D),z.render(A,U.current),V(o),v&&V(.4*o),z.setRenderTarget(null),E.current.visible=!0,A.overrideMaterial=M,A.background=S)}),l.useImperativeHandle(b,()=>E.current,[]),l.createElement("group",(0,d.default)({"rotation-x":Math.PI/2},w,{ref:E}),l.createElement("mesh",{renderOrder:g,geometry:_,scale:[1,-1,1],rotation:[-Math.PI/2,0,0]},l.createElement("meshBasicMaterial",{transparent:!0,map:D.texture,opacity:r,depthWrite:y})),l.createElement("orthographicCamera",{ref:U,args:[-n/2,n/2,i/2,-i/2,a,s]}))});var x=m,y=e.i(70950),y=y,g=m;let w=parseInt(m.REVISION.replace(/\D+/g,"")),b=(n={cellSize:.5,sectionSize:1,fadeDistance:100,fadeStrength:1,fadeFrom:1,cellThickness:.5,sectionThickness:1,cellColor:new x.Color,sectionColor:new x.Color,infiniteGrid:!1,followCamera:!1,worldCamProjPosition:new x.Vector3,worldPlanePosition:new x.Vector3},i=`
    varying vec3 localPosition;
    varying vec4 worldPosition;

    uniform vec3 worldCamProjPosition;
    uniform vec3 worldPlanePosition;
    uniform float fadeDistance;
    uniform bool infiniteGrid;
    uniform bool followCamera;

    void main() {
      localPosition = position.xzy;
      if (infiniteGrid) localPosition *= 1.0 + fadeDistance;
      
      worldPosition = modelMatrix * vec4(localPosition, 1.0);
      if (followCamera) {
        worldPosition.xyz += (worldCamProjPosition - worldPlanePosition);
        localPosition = (inverse(modelMatrix) * worldPosition).xyz;
      }

      gl_Position = projectionMatrix * viewMatrix * worldPosition;
    }
  `,o=`
    varying vec3 localPosition;
    varying vec4 worldPosition;

    uniform vec3 worldCamProjPosition;
    uniform float cellSize;
    uniform float sectionSize;
    uniform vec3 cellColor;
    uniform vec3 sectionColor;
    uniform float fadeDistance;
    uniform float fadeStrength;
    uniform float fadeFrom;
    uniform float cellThickness;
    uniform float sectionThickness;

    float getGrid(float size, float thickness) {
      vec2 r = localPosition.xz / size;
      vec2 grid = abs(fract(r - 0.5) - 0.5) / fwidth(r);
      float line = min(grid.x, grid.y) + 1.0 - thickness;
      return 1.0 - min(line, 1.0);
    }

    void main() {
      float g1 = getGrid(cellSize, cellThickness);
      float g2 = getGrid(sectionSize, sectionThickness);

      vec3 from = worldCamProjPosition*vec3(fadeFrom);
      float dist = distance(from, worldPosition.xyz);
      float d = 1.0 - min(dist / fadeDistance, 1.0);
      vec3 color = mix(cellColor, sectionColor, min(1.0, sectionThickness * g2));

      gl_FragColor = vec4(color, (g1 + g2) * pow(d, fadeStrength));
      gl_FragColor.a = mix(0.75 * gl_FragColor.a, gl_FragColor.a, g2);
      if (gl_FragColor.a <= 0.0) discard;

      #include <tonemapping_fragment>
      #include <${w>=154?"colorspace_fragment":"encodings_fragment"}>
    }
  `,(a=class extends g.ShaderMaterial{constructor(e){for(const t in super({vertexShader:i,fragmentShader:o,...e}),n)this.uniforms[t]=new g.Uniform(n[t]),Object.defineProperty(this,t,{get(){return this.uniforms[t].value},set(e){this.uniforms[t].value=e}});this.uniforms=g.UniformsUtils.clone(this.uniforms)}}).key=g.MathUtils.generateUUID(),a),S=l.forwardRef(({args:e,cellColor:t="#000000",sectionColor:r="#2080ff",cellSize:n=.5,sectionSize:i=1,followCamera:o=!1,infiniteGrid:a=!1,fadeDistance:s=100,fadeStrength:u=1,fadeFrom:f=1,cellThickness:m=.5,sectionThickness:p=1,side:h=x.BackSide,...v},g)=>{(0,y.e)({GridMaterial:b});let w=l.useRef(null);l.useImperativeHandle(g,()=>w.current,[]);let S=new x.Plane,M=new x.Vector3(0,1,0),E=new x.Vector3(0,0,0);return(0,c.useFrame)(e=>{S.setFromNormalAndCoplanarPoint(M,E).applyMatrix4(w.current.matrixWorld);let t=w.current.material,r=t.uniforms.worldCamProjPosition,n=t.uniforms.worldPlanePosition;S.projectPoint(e.camera.position,r.value),n.value.set(0,0,0).applyMatrix4(w.current.matrixWorld)}),l.createElement("mesh",(0,d.default)({ref:w,frustumCulled:!1},v),l.createElement("gridMaterial",(0,d.default)({transparent:!0,"extensions-derivatives":!0,side:h},{cellSize:n,sectionSize:i,cellColor:t,sectionColor:r,cellThickness:m,sectionThickness:p},{fadeDistance:s,fadeStrength:u,fadeFrom:f,infiniteGrid:a,followCamera:o})),l.createElement("planeGeometry",{args:e}))});var M=e.i(30297),E=e.i(77806),A=e.i(11547),z=e.i(68246),U=m,D=m;let _=new D.Box3,C=new D.Vector3;class B extends D.InstancedBufferGeometry{constructor(){super(),this.isLineSegmentsGeometry=!0,this.type="LineSegmentsGeometry",this.setIndex([0,2,1,2,3,1,2,4,3,4,5,3,4,6,5,6,7,5]),this.setAttribute("position",new D.Float32BufferAttribute([-1,2,0,1,2,0,-1,1,0,1,1,0,-1,0,0,1,0,0,-1,-1,0,1,-1,0],3)),this.setAttribute("uv",new D.Float32BufferAttribute([-1,2,1,2,-1,1,1,1,-1,-1,1,-1,-1,-2,1,-2],2))}applyMatrix4(e){let t=this.attributes.instanceStart,r=this.attributes.instanceEnd;return void 0!==t&&(t.applyMatrix4(e),r.applyMatrix4(e),t.needsUpdate=!0),null!==this.boundingBox&&this.computeBoundingBox(),null!==this.boundingSphere&&this.computeBoundingSphere(),this}setPositions(e){let t;e instanceof Float32Array?t=e:Array.isArray(e)&&(t=new Float32Array(e));let r=new D.InstancedInterleavedBuffer(t,6,1);return this.setAttribute("instanceStart",new D.InterleavedBufferAttribute(r,3,0)),this.setAttribute("instanceEnd",new D.InterleavedBufferAttribute(r,3,3)),this.computeBoundingBox(),this.computeBoundingSphere(),this}setColors(e,t=3){let r;e instanceof Float32Array?r=e:Array.isArray(e)&&(r=new Float32Array(e));let n=new D.InstancedInterleavedBuffer(r,2*t,1);return this.setAttribute("instanceColorStart",new D.InterleavedBufferAttribute(n,t,0)),this.setAttribute("instanceColorEnd",new D.InterleavedBufferAttribute(n,t,t)),this}fromWireframeGeometry(e){return this.setPositions(e.attributes.position.array),this}fromEdgesGeometry(e){return this.setPositions(e.attributes.position.array),this}fromMesh(e){return this.fromWireframeGeometry(new D.WireframeGeometry(e.geometry)),this}fromLineSegments(e){let t=e.geometry;return this.setPositions(t.attributes.position.array),this}computeBoundingBox(){null===this.boundingBox&&(this.boundingBox=new D.Box3);let e=this.attributes.instanceStart,t=this.attributes.instanceEnd;void 0!==e&&void 0!==t&&(this.boundingBox.setFromBufferAttribute(e),_.setFromBufferAttribute(t),this.boundingBox.union(_))}computeBoundingSphere(){null===this.boundingSphere&&(this.boundingSphere=new D.Sphere),null===this.boundingBox&&this.computeBoundingBox();let e=this.attributes.instanceStart,t=this.attributes.instanceEnd;if(void 0!==e&&void 0!==t){let r=this.boundingSphere.center;this.boundingBox.getCenter(r);let n=0;for(let i=0,o=e.count;i<o;i++)C.fromBufferAttribute(e,i),n=Math.max(n,r.distanceToSquared(C)),C.fromBufferAttribute(t,i),n=Math.max(n,r.distanceToSquared(C));this.boundingSphere.radius=Math.sqrt(n),isNaN(this.boundingSphere.radius)&&console.error("THREE.LineSegmentsGeometry.computeBoundingSphere(): Computed radius is NaN. The instanced position data is likely to have NaN values.",this)}}toJSON(){}applyMatrix(e){return console.warn("THREE.LineSegmentsGeometry: applyMatrix() has been renamed to applyMatrix4()."),this.applyMatrix4(e)}}var j=m,P=e.i(8560);let L=parseInt(m.REVISION.replace(/\D+/g,""));class V extends j.ShaderMaterial{constructor(e){super({type:"LineMaterial",uniforms:j.UniformsUtils.clone(j.UniformsUtils.merge([P.UniformsLib.common,P.UniformsLib.fog,{worldUnits:{value:1},linewidth:{value:1},resolution:{value:new j.Vector2(1,1)},dashOffset:{value:0},dashScale:{value:1},dashSize:{value:1},gapSize:{value:1}}])),vertexShader:`
				#include <common>
				#include <fog_pars_vertex>
				#include <logdepthbuf_pars_vertex>
				#include <clipping_planes_pars_vertex>

				uniform float linewidth;
				uniform vec2 resolution;

				attribute vec3 instanceStart;
				attribute vec3 instanceEnd;

				#ifdef USE_COLOR
					#ifdef USE_LINE_COLOR_ALPHA
						varying vec4 vLineColor;
						attribute vec4 instanceColorStart;
						attribute vec4 instanceColorEnd;
					#else
						varying vec3 vLineColor;
						attribute vec3 instanceColorStart;
						attribute vec3 instanceColorEnd;
					#endif
				#endif

				#ifdef WORLD_UNITS

					varying vec4 worldPos;
					varying vec3 worldStart;
					varying vec3 worldEnd;

					#ifdef USE_DASH

						varying vec2 vUv;

					#endif

				#else

					varying vec2 vUv;

				#endif

				#ifdef USE_DASH

					uniform float dashScale;
					attribute float instanceDistanceStart;
					attribute float instanceDistanceEnd;
					varying float vLineDistance;

				#endif

				void trimSegment( const in vec4 start, inout vec4 end ) {

					// trim end segment so it terminates between the camera plane and the near plane

					// conservative estimate of the near plane
					float a = projectionMatrix[ 2 ][ 2 ]; // 3nd entry in 3th column
					float b = projectionMatrix[ 3 ][ 2 ]; // 3nd entry in 4th column
					float nearEstimate = - 0.5 * b / a;

					float alpha = ( nearEstimate - start.z ) / ( end.z - start.z );

					end.xyz = mix( start.xyz, end.xyz, alpha );

				}

				void main() {

					#ifdef USE_COLOR

						vLineColor = ( position.y < 0.5 ) ? instanceColorStart : instanceColorEnd;

					#endif

					#ifdef USE_DASH

						vLineDistance = ( position.y < 0.5 ) ? dashScale * instanceDistanceStart : dashScale * instanceDistanceEnd;
						vUv = uv;

					#endif

					float aspect = resolution.x / resolution.y;

					// camera space
					vec4 start = modelViewMatrix * vec4( instanceStart, 1.0 );
					vec4 end = modelViewMatrix * vec4( instanceEnd, 1.0 );

					#ifdef WORLD_UNITS

						worldStart = start.xyz;
						worldEnd = end.xyz;

					#else

						vUv = uv;

					#endif

					// special case for perspective projection, and segments that terminate either in, or behind, the camera plane
					// clearly the gpu firmware has a way of addressing this issue when projecting into ndc space
					// but we need to perform ndc-space calculations in the shader, so we must address this issue directly
					// perhaps there is a more elegant solution -- WestLangley

					bool perspective = ( projectionMatrix[ 2 ][ 3 ] == - 1.0 ); // 4th entry in the 3rd column

					if ( perspective ) {

						if ( start.z < 0.0 && end.z >= 0.0 ) {

							trimSegment( start, end );

						} else if ( end.z < 0.0 && start.z >= 0.0 ) {

							trimSegment( end, start );

						}

					}

					// clip space
					vec4 clipStart = projectionMatrix * start;
					vec4 clipEnd = projectionMatrix * end;

					// ndc space
					vec3 ndcStart = clipStart.xyz / clipStart.w;
					vec3 ndcEnd = clipEnd.xyz / clipEnd.w;

					// direction
					vec2 dir = ndcEnd.xy - ndcStart.xy;

					// account for clip-space aspect ratio
					dir.x *= aspect;
					dir = normalize( dir );

					#ifdef WORLD_UNITS

						// get the offset direction as perpendicular to the view vector
						vec3 worldDir = normalize( end.xyz - start.xyz );
						vec3 offset;
						if ( position.y < 0.5 ) {

							offset = normalize( cross( start.xyz, worldDir ) );

						} else {

							offset = normalize( cross( end.xyz, worldDir ) );

						}

						// sign flip
						if ( position.x < 0.0 ) offset *= - 1.0;

						float forwardOffset = dot( worldDir, vec3( 0.0, 0.0, 1.0 ) );

						// don't extend the line if we're rendering dashes because we
						// won't be rendering the endcaps
						#ifndef USE_DASH

							// extend the line bounds to encompass  endcaps
							start.xyz += - worldDir * linewidth * 0.5;
							end.xyz += worldDir * linewidth * 0.5;

							// shift the position of the quad so it hugs the forward edge of the line
							offset.xy -= dir * forwardOffset;
							offset.z += 0.5;

						#endif

						// endcaps
						if ( position.y > 1.0 || position.y < 0.0 ) {

							offset.xy += dir * 2.0 * forwardOffset;

						}

						// adjust for linewidth
						offset *= linewidth * 0.5;

						// set the world position
						worldPos = ( position.y < 0.5 ) ? start : end;
						worldPos.xyz += offset;

						// project the worldpos
						vec4 clip = projectionMatrix * worldPos;

						// shift the depth of the projected points so the line
						// segments overlap neatly
						vec3 clipPose = ( position.y < 0.5 ) ? ndcStart : ndcEnd;
						clip.z = clipPose.z * clip.w;

					#else

						vec2 offset = vec2( dir.y, - dir.x );
						// undo aspect ratio adjustment
						dir.x /= aspect;
						offset.x /= aspect;

						// sign flip
						if ( position.x < 0.0 ) offset *= - 1.0;

						// endcaps
						if ( position.y < 0.0 ) {

							offset += - dir;

						} else if ( position.y > 1.0 ) {

							offset += dir;

						}

						// adjust for linewidth
						offset *= linewidth;

						// adjust for clip-space to screen-space conversion // maybe resolution should be based on viewport ...
						offset /= resolution.y;

						// select end
						vec4 clip = ( position.y < 0.5 ) ? clipStart : clipEnd;

						// back to clip space
						offset *= clip.w;

						clip.xy += offset;

					#endif

					gl_Position = clip;

					vec4 mvPosition = ( position.y < 0.5 ) ? start : end; // this is an approximation

					#include <logdepthbuf_vertex>
					#include <clipping_planes_vertex>
					#include <fog_vertex>

				}
			`,fragmentShader:`
				uniform vec3 diffuse;
				uniform float opacity;
				uniform float linewidth;

				#ifdef USE_DASH

					uniform float dashOffset;
					uniform float dashSize;
					uniform float gapSize;

				#endif

				varying float vLineDistance;

				#ifdef WORLD_UNITS

					varying vec4 worldPos;
					varying vec3 worldStart;
					varying vec3 worldEnd;

					#ifdef USE_DASH

						varying vec2 vUv;

					#endif

				#else

					varying vec2 vUv;

				#endif

				#include <common>
				#include <fog_pars_fragment>
				#include <logdepthbuf_pars_fragment>
				#include <clipping_planes_pars_fragment>

				#ifdef USE_COLOR
					#ifdef USE_LINE_COLOR_ALPHA
						varying vec4 vLineColor;
					#else
						varying vec3 vLineColor;
					#endif
				#endif

				vec2 closestLineToLine(vec3 p1, vec3 p2, vec3 p3, vec3 p4) {

					float mua;
					float mub;

					vec3 p13 = p1 - p3;
					vec3 p43 = p4 - p3;

					vec3 p21 = p2 - p1;

					float d1343 = dot( p13, p43 );
					float d4321 = dot( p43, p21 );
					float d1321 = dot( p13, p21 );
					float d4343 = dot( p43, p43 );
					float d2121 = dot( p21, p21 );

					float denom = d2121 * d4343 - d4321 * d4321;

					float numer = d1343 * d4321 - d1321 * d4343;

					mua = numer / denom;
					mua = clamp( mua, 0.0, 1.0 );
					mub = ( d1343 + d4321 * ( mua ) ) / d4343;
					mub = clamp( mub, 0.0, 1.0 );

					return vec2( mua, mub );

				}

				void main() {

					#include <clipping_planes_fragment>

					#ifdef USE_DASH

						if ( vUv.y < - 1.0 || vUv.y > 1.0 ) discard; // discard endcaps

						if ( mod( vLineDistance + dashOffset, dashSize + gapSize ) > dashSize ) discard; // todo - FIX

					#endif

					float alpha = opacity;

					#ifdef WORLD_UNITS

						// Find the closest points on the view ray and the line segment
						vec3 rayEnd = normalize( worldPos.xyz ) * 1e5;
						vec3 lineDir = worldEnd - worldStart;
						vec2 params = closestLineToLine( worldStart, worldEnd, vec3( 0.0, 0.0, 0.0 ), rayEnd );

						vec3 p1 = worldStart + lineDir * params.x;
						vec3 p2 = rayEnd * params.y;
						vec3 delta = p1 - p2;
						float len = length( delta );
						float norm = len / linewidth;

						#ifndef USE_DASH

							#ifdef USE_ALPHA_TO_COVERAGE

								float dnorm = fwidth( norm );
								alpha = 1.0 - smoothstep( 0.5 - dnorm, 0.5 + dnorm, norm );

							#else

								if ( norm > 0.5 ) {

									discard;

								}

							#endif

						#endif

					#else

						#ifdef USE_ALPHA_TO_COVERAGE

							// artifacts appear on some hardware if a derivative is taken within a conditional
							float a = vUv.x;
							float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
							float len2 = a * a + b * b;
							float dlen = fwidth( len2 );

							if ( abs( vUv.y ) > 1.0 ) {

								alpha = 1.0 - smoothstep( 1.0 - dlen, 1.0 + dlen, len2 );

							}

						#else

							if ( abs( vUv.y ) > 1.0 ) {

								float a = vUv.x;
								float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
								float len2 = a * a + b * b;

								if ( len2 > 1.0 ) discard;

							}

						#endif

					#endif

					vec4 diffuseColor = vec4( diffuse, alpha );
					#ifdef USE_COLOR
						#ifdef USE_LINE_COLOR_ALPHA
							diffuseColor *= vLineColor;
						#else
							diffuseColor.rgb *= vLineColor;
						#endif
					#endif

					#include <logdepthbuf_fragment>

					gl_FragColor = diffuseColor;

					#include <tonemapping_fragment>
					#include <${L>=154?"colorspace_fragment":"encodings_fragment"}>
					#include <fog_fragment>
					#include <premultiplied_alpha_fragment>

				}
			`,clipping:!0}),this.isLineMaterial=!0,this.onBeforeCompile=function(){this.transparent?this.defines.USE_LINE_COLOR_ALPHA="1":delete this.defines.USE_LINE_COLOR_ALPHA},Object.defineProperties(this,{color:{enumerable:!0,get:function(){return this.uniforms.diffuse.value},set:function(e){this.uniforms.diffuse.value=e}},worldUnits:{enumerable:!0,get:function(){return"WORLD_UNITS"in this.defines},set:function(e){!0===e?this.defines.WORLD_UNITS="":delete this.defines.WORLD_UNITS}},linewidth:{enumerable:!0,get:function(){return this.uniforms.linewidth.value},set:function(e){this.uniforms.linewidth.value=e}},dashed:{enumerable:!0,get:function(){return"USE_DASH"in this.defines},set(e){!!e!="USE_DASH"in this.defines&&(this.needsUpdate=!0),!0===e?this.defines.USE_DASH="":delete this.defines.USE_DASH}},dashScale:{enumerable:!0,get:function(){return this.uniforms.dashScale.value},set:function(e){this.uniforms.dashScale.value=e}},dashSize:{enumerable:!0,get:function(){return this.uniforms.dashSize.value},set:function(e){this.uniforms.dashSize.value=e}},dashOffset:{enumerable:!0,get:function(){return this.uniforms.dashOffset.value},set:function(e){this.uniforms.dashOffset.value=e}},gapSize:{enumerable:!0,get:function(){return this.uniforms.gapSize.value},set:function(e){this.uniforms.gapSize.value=e}},opacity:{enumerable:!0,get:function(){return this.uniforms.opacity.value},set:function(e){this.uniforms.opacity.value=e}},resolution:{enumerable:!0,get:function(){return this.uniforms.resolution.value},set:function(e){this.uniforms.resolution.value.copy(e)}},alphaToCoverage:{enumerable:!0,get:function(){return"USE_ALPHA_TO_COVERAGE"in this.defines},set:function(e){!!e!="USE_ALPHA_TO_COVERAGE"in this.defines&&(this.needsUpdate=!0),!0===e?(this.defines.USE_ALPHA_TO_COVERAGE="",this.extensions.derivatives=!0):(delete this.defines.USE_ALPHA_TO_COVERAGE,this.extensions.derivatives=!1)}}}),this.setValues(e)}}let O=L>=125?"uv1":"uv2",T=new U.Vector4,F=new U.Vector3,R=new U.Vector3,I=new U.Vector4,W=new U.Vector4,G=new U.Vector4,k=new U.Vector3,H=new U.Matrix4,N=new U.Line3,$=new U.Vector3,q=new U.Box3,X=new U.Sphere,Z=new U.Vector4;function J(e,t,n){return Z.set(0,0,-t,1).applyMatrix4(e.projectionMatrix),Z.multiplyScalar(1/Z.w),Z.x=r/n.width,Z.y=r/n.height,Z.applyMatrix4(e.projectionMatrixInverse),Z.multiplyScalar(1/Z.w),Math.abs(Math.max(Z.x,Z.y))}class K extends U.Mesh{constructor(e=new B,t=new V({color:0xffffff*Math.random()})){super(e,t),this.isLineSegments2=!0,this.type="LineSegments2"}computeLineDistances(){let e=this.geometry,t=e.attributes.instanceStart,r=e.attributes.instanceEnd,n=new Float32Array(2*t.count);for(let e=0,i=0,o=t.count;e<o;e++,i+=2)F.fromBufferAttribute(t,e),R.fromBufferAttribute(r,e),n[i]=0===i?0:n[i-1],n[i+1]=n[i]+F.distanceTo(R);let i=new U.InstancedInterleavedBuffer(n,2,1);return e.setAttribute("instanceDistanceStart",new U.InterleavedBufferAttribute(i,1,0)),e.setAttribute("instanceDistanceEnd",new U.InterleavedBufferAttribute(i,1,1)),this}raycast(e,n){let i,o,a=this.material.worldUnits,s=e.camera;null!==s||a||console.error('LineSegments2: "Raycaster.camera" needs to be set in order to raycast against LineSegments2 while worldUnits is set to false.');let l=void 0!==e.params.Line2&&e.params.Line2.threshold||0;t=e.ray;let u=this.matrixWorld,c=this.geometry,f=this.material;if(r=f.linewidth+l,null===c.boundingSphere&&c.computeBoundingSphere(),X.copy(c.boundingSphere).applyMatrix4(u),a)i=.5*r;else{let e=Math.max(s.near,X.distanceToPoint(t.origin));i=J(s,e,f.resolution)}if(X.radius+=i,!1!==t.intersectsSphere(X)){if(null===c.boundingBox&&c.computeBoundingBox(),q.copy(c.boundingBox).applyMatrix4(u),a)o=.5*r;else{let e=Math.max(s.near,q.distanceToPoint(t.origin));o=J(s,e,f.resolution)}q.expandByScalar(o),!1!==t.intersectsBox(q)&&(a?function(e,n){let i=e.matrixWorld,o=e.geometry,a=o.attributes.instanceStart,s=o.attributes.instanceEnd,l=Math.min(o.instanceCount,a.count);for(let o=0;o<l;o++){N.start.fromBufferAttribute(a,o),N.end.fromBufferAttribute(s,o),N.applyMatrix4(i);let l=new U.Vector3,u=new U.Vector3;t.distanceSqToSegment(N.start,N.end,u,l),u.distanceTo(l)<.5*r&&n.push({point:u,pointOnLine:l,distance:t.origin.distanceTo(u),object:e,face:null,faceIndex:o,uv:null,[O]:null})}}(this,n):function(e,n,i){let o=n.projectionMatrix,a=e.material.resolution,s=e.matrixWorld,l=e.geometry,u=l.attributes.instanceStart,c=l.attributes.instanceEnd,f=Math.min(l.instanceCount,u.count),d=-n.near;t.at(1,G),G.w=1,G.applyMatrix4(n.matrixWorldInverse),G.applyMatrix4(o),G.multiplyScalar(1/G.w),G.x*=a.x/2,G.y*=a.y/2,G.z=0,k.copy(G),H.multiplyMatrices(n.matrixWorldInverse,s);for(let n=0;n<f;n++){if(I.fromBufferAttribute(u,n),W.fromBufferAttribute(c,n),I.w=1,W.w=1,I.applyMatrix4(H),W.applyMatrix4(H),I.z>d&&W.z>d)continue;if(I.z>d){let e=I.z-W.z,t=(I.z-d)/e;I.lerp(W,t)}else if(W.z>d){let e=W.z-I.z,t=(W.z-d)/e;W.lerp(I,t)}I.applyMatrix4(o),W.applyMatrix4(o),I.multiplyScalar(1/I.w),W.multiplyScalar(1/W.w),I.x*=a.x/2,I.y*=a.y/2,W.x*=a.x/2,W.y*=a.y/2,N.start.copy(I),N.start.z=0,N.end.copy(W),N.end.z=0;let l=N.closestPointToPointParameter(k,!0);N.at(l,$);let f=U.MathUtils.lerp(I.z,W.z,l),m=f>=-1&&f<=1,p=k.distanceTo($)<.5*r;if(m&&p){N.start.fromBufferAttribute(u,n),N.end.fromBufferAttribute(c,n),N.start.applyMatrix4(s),N.end.applyMatrix4(s);let r=new U.Vector3,o=new U.Vector3;t.distanceSqToSegment(N.start,N.end,o,r),i.push({point:o,pointOnLine:r,distance:t.origin.distanceTo(o),object:e,face:null,faceIndex:n,uv:null,[O]:null})}}}(this,s,n))}}onBeforeRender(e){let t=this.material.uniforms;t&&t.resolution&&(e.getViewport(T),this.material.uniforms.resolution.value.set(T.z,T.w))}}class Y extends B{constructor(){super(),this.isLineGeometry=!0,this.type="LineGeometry"}setPositions(e){let t=e.length-3,r=new Float32Array(2*t);for(let n=0;n<t;n+=3)r[2*n]=e[n],r[2*n+1]=e[n+1],r[2*n+2]=e[n+2],r[2*n+3]=e[n+3],r[2*n+4]=e[n+4],r[2*n+5]=e[n+5];return super.setPositions(r),this}setColors(e,t=3){let r=e.length-t,n=new Float32Array(2*r);if(3===t)for(let i=0;i<r;i+=t)n[2*i]=e[i],n[2*i+1]=e[i+1],n[2*i+2]=e[i+2],n[2*i+3]=e[i+3],n[2*i+4]=e[i+4],n[2*i+5]=e[i+5];else for(let i=0;i<r;i+=t)n[2*i]=e[i],n[2*i+1]=e[i+1],n[2*i+2]=e[i+2],n[2*i+3]=e[i+3],n[2*i+4]=e[i+4],n[2*i+5]=e[i+5],n[2*i+6]=e[i+6],n[2*i+7]=e[i+7];return super.setColors(n,t),this}fromLine(e){let t=e.geometry;return this.setPositions(t.attributes.position.array),this}}class Q extends K{constructor(e=new Y,t=new V({color:0xffffff*Math.random()})){super(e,t),this.isLine2=!0,this.type="Line2"}}let ee=l.forwardRef(function({points:e,color:t=0xffffff,vertexColors:r,linewidth:n,lineWidth:i,segments:o,dashed:a,...s},u){var c,p;let h=(0,f.useThree)(e=>e.size),v=l.useMemo(()=>o?new K:new Q,[o]),[x]=l.useState(()=>new V),y=(null==r||null==(c=r[0])?void 0:c.length)===4?4:3,g=l.useMemo(()=>{let n=o?new B:new Y,i=e.map(e=>{let t=Array.isArray(e);return e instanceof m.Vector3||e instanceof m.Vector4?[e.x,e.y,e.z]:e instanceof m.Vector2?[e.x,e.y,0]:t&&3===e.length?[e[0],e[1],e[2]]:t&&2===e.length?[e[0],e[1],0]:e});if(n.setPositions(i.flat()),r){t=0xffffff;let e=r.map(e=>e instanceof m.Color?e.toArray():e);n.setColors(e.flat(),y)}return n},[e,o,r,y]);return l.useLayoutEffect(()=>{v.computeLineDistances()},[e,v]),l.useLayoutEffect(()=>{a?x.defines.USE_DASH="":delete x.defines.USE_DASH,x.needsUpdate=!0},[a,x]),l.useEffect(()=>()=>{g.dispose(),x.dispose()},[g]),l.createElement("primitive",(0,d.default)({object:v,ref:u},s),l.createElement("primitive",{object:g,attach:"geometry"}),l.createElement("primitive",(0,d.default)({object:x,attach:"material",color:t,vertexColors:!!r,resolution:[h.width,h.height],linewidth:null!=(p=null!=n?n:i)?p:1,dashed:a,transparent:4===y},s)))}),et=l.forwardRef(({threshold:e=15,geometry:t,...r},n)=>{let i=l.useRef(null);l.useImperativeHandle(n,()=>i.current,[]);let o=l.useMemo(()=>[0,0,0,1,0,0],[]),a=l.useRef(null),s=l.useRef(null);return l.useLayoutEffect(()=>{let r=i.current.parent,n=null!=t?t:null==r?void 0:r.geometry;if(!n||a.current===n&&s.current===e)return;a.current=n,s.current=e;let o=new m.EdgesGeometry(n,e).attributes.position.array;i.current.geometry.setPositions(o),i.current.geometry.attributes.instanceStart.needsUpdate=!0,i.current.geometry.attributes.instanceEnd.needsUpdate=!0,i.current.computeLineDistances()}),l.createElement(ee,(0,d.default)({segments:!0,points:o,ref:i,raycast:()=>null},r))});var er=y,en=m;class ei extends en.BufferGeometry{constructor(e,t,r,n){super();const i=[],o=[],a=[],s=new en.Vector3,l=new en.Matrix4;l.makeRotationFromEuler(r),l.setPosition(t);const u=new en.Matrix4;function c(t,r,n){r.applyMatrix4(e.matrixWorld),r.applyMatrix4(u),n.transformDirection(e.matrixWorld),t.push(new eo(r.clone(),n.clone()))}function f(e,t){let r=[],i=.5*Math.abs(n.dot(t));for(let n=0;n<e.length;n+=3){let o,a,s,l,u,c,f,m=e[n+0].position.dot(t)-i,p=e[n+1].position.dot(t)-i,h=e[n+2].position.dot(t)-i;switch(+!!(u=m>0)+ +!!(c=p>0)+ +!!(f=h>0)){case 0:r.push(e[n]),r.push(e[n+1]),r.push(e[n+2]);break;case 1:if(u&&(o=e[n+1],a=e[n+2],s=d(e[n],o,t,i),l=d(e[n],a,t,i)),c){o=e[n],a=e[n+2],s=d(e[n+1],o,t,i),l=d(e[n+1],a,t,i),r.push(s),r.push(a.clone()),r.push(o.clone()),r.push(a.clone()),r.push(s.clone()),r.push(l);break}f&&(o=e[n],a=e[n+1],s=d(e[n+2],o,t,i),l=d(e[n+2],a,t,i)),r.push(o.clone()),r.push(a.clone()),r.push(s),r.push(l),r.push(s.clone()),r.push(a.clone());break;case 2:u||(a=d(o=e[n].clone(),e[n+1],t,i),s=d(o,e[n+2],t,i),r.push(o),r.push(a),r.push(s)),c||(a=d(o=e[n+1].clone(),e[n+2],t,i),s=d(o,e[n],t,i),r.push(o),r.push(a),r.push(s)),f||(a=d(o=e[n+2].clone(),e[n],t,i),s=d(o,e[n+1],t,i),r.push(o),r.push(a),r.push(s))}}return r}function d(e,t,r,n){let i=e.position.dot(r)-n,o=i/(i-(t.position.dot(r)-n));return new eo(new en.Vector3(e.position.x+o*(t.position.x-e.position.x),e.position.y+o*(t.position.y-e.position.y),e.position.z+o*(t.position.z-e.position.z)),new en.Vector3(e.normal.x+o*(t.normal.x-e.normal.x),e.normal.y+o*(t.normal.y-e.normal.y),e.normal.z+o*(t.normal.z-e.normal.z)))}u.copy(l).invert(),function(){let t,r=[],u=new en.Vector3,d=new en.Vector3;if(!0===e.geometry.isGeometry)return console.error("THREE.DecalGeometry no longer supports THREE.Geometry. Use BufferGeometry instead.");let m=e.geometry,p=m.attributes.position,h=m.attributes.normal;if(null!==m.index){let e=m.index;for(t=0;t<e.count;t++)u.fromBufferAttribute(p,e.getX(t)),d.fromBufferAttribute(h,e.getX(t)),c(r,u,d)}else for(t=0;t<p.count;t++)u.fromBufferAttribute(p,t),d.fromBufferAttribute(h,t),c(r,u,d);for(r=f(r,s.set(1,0,0)),r=f(r,s.set(-1,0,0)),r=f(r,s.set(0,1,0)),r=f(r,s.set(0,-1,0)),r=f(r,s.set(0,0,1)),r=f(r,s.set(0,0,-1)),t=0;t<r.length;t++){let e=r[t];a.push(.5+e.position.x/n.x,.5+e.position.y/n.y),e.position.applyMatrix4(l),i.push(e.position.x,e.position.y,e.position.z),o.push(e.normal.x,e.normal.y,e.normal.z)}}(),this.setAttribute("position",new en.Float32BufferAttribute(i,3)),this.setAttribute("normal",new en.Float32BufferAttribute(o,3)),this.setAttribute("uv",new en.Float32BufferAttribute(a,2))}}class eo{constructor(e,t){this.position=e,this.normal=t}clone(){return new this.constructor(this.position.clone(),this.normal.clone())}}function ea(e=[0,0,0]){return Array.isArray(e)?e:e instanceof m.Vector3||e instanceof m.Euler?[e.x,e.y,e.z]:[e,e,e]}let es=l.forwardRef(function({debug:e,depthTest:t=!1,polygonOffsetFactor:r=-10,map:n,mesh:i,children:o,position:a,rotation:s,scale:u,...c},f){let p=l.useRef(null);l.useImperativeHandle(f,()=>p.current);let h=l.useRef(null),v=l.useRef({position:new m.Vector3,rotation:new m.Euler,scale:new m.Vector3(1,1,1)});return l.useLayoutEffect(()=>{let e=(null==i?void 0:i.current)||p.current.parent,t=p.current;if(!(e instanceof m.Mesh))throw Error('Decal must have a Mesh as parent or specify its "mesh" prop');if(e){(0,er.s)(v.current,{position:a,scale:u});let r=e.matrixWorld.clone();if(e.matrixWorld.identity(),s&&"number"!=typeof s)(0,er.s)(v.current,{rotation:s});else{let t=new m.Object3D;t.position.copy(v.current.position);let r=e.geometry.attributes.position.array;void 0===e.geometry.attributes.normal&&e.geometry.computeVertexNormals();let n=e.geometry.attributes.normal.array,i=1/0,o=new m.Vector3,a=t.position.x,l=t.position.y,u=t.position.z,c=r.length,f=-1;for(let e=0;e<c;e+=3){let t=r[e],n=r[e+1],o=r[e+2],s=t-a,c=n-l,d=o-u,m=s*s+c*c+d*d;m<i&&(i=m,f=e)}o.fromArray(n,f),t.lookAt(t.position.clone().add(o)),t.rotateZ(Math.PI),t.rotateY(Math.PI),"number"==typeof s&&t.rotateZ(s),(0,er.s)(v.current,{rotation:t.rotation})}return h.current&&(0,er.s)(h.current,v.current),t.geometry=new ei(e,v.current.position,v.current.rotation,v.current.scale),e.matrixWorld=r,()=>{t.geometry.dispose()}}},[i,...ea(a),...ea(u),...ea(s)]),l.useLayoutEffect(()=>{h.current&&h.current.traverse(e=>e.raycast=()=>null)},[e]),l.createElement("mesh",(0,d.default)({ref:p,"material-transparent":!0,"material-polygonOffset":!0,"material-polygonOffsetFactor":r,"material-depthTest":t,"material-map":n},c),o,e&&l.createElement("mesh",{ref:h},l.createElement("boxGeometry",null),l.createElement("meshNormalMaterial",{wireframe:!0}),l.createElement("axesHelper",null)))});var el=m;class eu extends el.BufferGeometry{constructor(e=new el.Mesh,t=new el.Vector3,r=new el.Euler,n=new el.Vector3(1,1,1)){super();const i=[],o=[],a=[],s=new el.Vector3,l=new el.Matrix3().getNormalMatrix(e.matrixWorld),u=new el.Matrix4;u.makeRotationFromEuler(r),u.setPosition(t);const c=new el.Matrix4;function f(t,r,n=null){r.applyMatrix4(e.matrixWorld),r.applyMatrix4(c),n?(n.applyNormalMatrix(l),t.push(new ec(r.clone(),n.clone()))):t.push(new ec(r.clone()))}function d(e,t){let r=[],i=.5*Math.abs(n.dot(t));for(let n=0;n<e.length;n+=3){let o,a,s,l,u=e[n+0].position.dot(t)-i,c=e[n+1].position.dot(t)-i,f=e[n+2].position.dot(t)-i,d=u>0,p=c>0,h=f>0;switch(+!!d+ +!!p+ +!!h){case 0:r.push(e[n]),r.push(e[n+1]),r.push(e[n+2]);break;case 1:if(d&&(o=e[n+1],a=e[n+2],s=m(e[n],o,t,i),l=m(e[n],a,t,i)),p){o=e[n],a=e[n+2],s=m(e[n+1],o,t,i),l=m(e[n+1],a,t,i),r.push(s),r.push(a.clone()),r.push(o.clone()),r.push(a.clone()),r.push(s.clone()),r.push(l);break}h&&(o=e[n],a=e[n+1],s=m(e[n+2],o,t,i),l=m(e[n+2],a,t,i)),r.push(o.clone()),r.push(a.clone()),r.push(s),r.push(l),r.push(s.clone()),r.push(a.clone());break;case 2:d||(a=m(o=e[n].clone(),e[n+1],t,i),s=m(o,e[n+2],t,i),r.push(o),r.push(a),r.push(s)),p||(a=m(o=e[n+1].clone(),e[n+2],t,i),s=m(o,e[n],t,i),r.push(o),r.push(a),r.push(s)),h||(a=m(o=e[n+2].clone(),e[n],t,i),s=m(o,e[n+1],t,i),r.push(o),r.push(a),r.push(s))}}return r}function m(e,t,r,n){let i=e.position.dot(r)-n,o=i/(i-(t.position.dot(r)-n)),a=new el.Vector3(e.position.x+o*(t.position.x-e.position.x),e.position.y+o*(t.position.y-e.position.y),e.position.z+o*(t.position.z-e.position.z)),s=null;return null!==e.normal&&null!==t.normal&&(s=new el.Vector3(e.normal.x+o*(t.normal.x-e.normal.x),e.normal.y+o*(t.normal.y-e.normal.y),e.normal.z+o*(t.normal.z-e.normal.z))),new ec(a,s)}c.copy(u).invert(),function(){let t=[],r=new el.Vector3,l=new el.Vector3,c=e.geometry,m=c.attributes.position,p=c.attributes.normal;if(null!==c.index){let e=c.index;for(let n=0;n<e.count;n++)r.fromBufferAttribute(m,e.getX(n)),p?(l.fromBufferAttribute(p,e.getX(n)),f(t,r,l)):f(t,r)}else{if(void 0===m)return;for(let e=0;e<m.count;e++)r.fromBufferAttribute(m,e),p?(l.fromBufferAttribute(p,e),f(t,r,l)):f(t,r)}t=d(t,s.set(1,0,0)),t=d(t,s.set(-1,0,0)),t=d(t,s.set(0,1,0)),t=d(t,s.set(0,-1,0)),t=d(t,s.set(0,0,1)),t=d(t,s.set(0,0,-1));for(let e=0;e<t.length;e++){let r=t[e];a.push(.5+r.position.x/n.x,.5+r.position.y/n.y),r.position.applyMatrix4(u),i.push(r.position.x,r.position.y,r.position.z),null!==r.normal&&o.push(r.normal.x,r.normal.y,r.normal.z)}}(),this.setAttribute("position",new el.Float32BufferAttribute(i,3)),this.setAttribute("uv",new el.Float32BufferAttribute(a,2)),o.length>0&&this.setAttribute("normal",new el.Float32BufferAttribute(o,3))}}class ec{constructor(e,t=null){this.position=e,this.normal=t}clone(){let e=this.position.clone(),t=null!==this.normal?this.normal.clone():null;return new this.constructor(e,t)}}function ef(e){return!!(e.userData?.chamOverlay||e.userData?.espBranding)}function ed(e){return/^Handle/i.test(e)}function em(e){let t=e.geometry.attributes.position;if(!t)return new m.Box3;let r=new m.Box3().setFromBufferAttribute(t);return r.applyMatrix4(e.matrix),r}let ep={skin:new m.Color("#e0a13a"),shirt:new m.Color("#3d6b9a"),pants:new m.Color("#2a3340")},eh=null;function ev(){return"u"<typeof document?null:(eh||(eh=function(){let e=document.createElement("canvas");e.width=1024,e.height=1024;let t=e.getContext("2d");if(!t)return new m.CanvasTexture(e);t.clearRect(0,0,1024,1024),t.save(),t.translate(61.44,40.96),t.scale(1024/16.6,1024/16.6),t.strokeStyle="#ffffff",t.lineWidth=1.85,t.lineCap="round",t.lineJoin="round",t.stroke(new Path2D("M12.2 5.15A4.55 4.55 0 1 0 12.35 10.2")),t.beginPath(),t.moveTo(8.15,8.05),t.lineTo(13,8.05),t.stroke(),t.restore();let r=new m.CanvasTexture(e);return r.colorSpace=m.SRGBColorSpace,r.anisotropy=8,r.minFilter=m.LinearFilter,r.magFilter=m.LinearFilter,r.generateMipmaps=!1,r.needsUpdate=!0,r}()),eh)}function ex(){let e=(0,l.useMemo)(()=>ev(),[]);return e?(0,s.jsx)(es,{position:[0,.06,.5],rotation:[0,0,0],scale:.78,children:(0,s.jsx)("meshStandardMaterial",{map:e,color:"#ffffff",transparent:!0,alphaTest:.08,depthWrite:!1,roughness:.88,metalness:0,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2})}):null}function ey({target:e}){return(0,l.useEffect)(()=>{if(e)return function(e){let t=ev();if(!t)return()=>{};let r=function(e){let t,r=function(e){if(0===e.length)return{torso:null,lArm:null,rArm:null,lLeg:null,rLeg:null};let t=new m.Box3;e.forEach(e=>t.union(new m.Box3(e.min,e.max)));let r=t.min.x,n=t.max.x,i=t.min.y,o=t.max.y,a=(r+n)*.5,s=Math.max(.01,o-i),l=Math.max(.01,n-r),u=e.map(e=>({aabb:e,cx:(e.min.x+e.max.x)*.5,sy:e.max.y-e.min.y,sx:e.max.x-e.min.x,foot:e.min.y})),c=null,f=-1;for(let e of u){if(Math.abs(e.cx-a)>.42*l)continue;let t=3*e.sy+e.sx;t>f&&(f=t,c=e.aabb)}c||(c=u.reduce((e,t)=>t.sy>e.sy?t:e).aabb);let d=u.filter(e=>e.aabb!==c).sort((e,t)=>e.foot-t.foot),p=d[0]?.aabb??null,h=d[1]?.aabb??null;p&&h&&(p.min.x+p.max.x)*.5>(h.min.x+h.max.x)*.5&&([p,h]=[h,p]);let v=u.filter(e=>!(e.aabb===c||e.aabb===p||e.aabb===h||Math.abs(e.cx-a)<.2*l)&&e.foot>i+.2*s),x=v.find(e=>e.cx<a)?.aabb??null,y=v.find(e=>e.cx>=a)?.aabb??null;return{torso:c,lArm:x,rArm:y,lLeg:p,rLeg:h}}((e.updateMatrixWorld(!0),t=[],e.traverse(r=>{let n,i;if(!(r instanceof m.Mesh)||ef(r))return;let o=(e.updateMatrixWorld(!0),n=e.matrixWorld.clone().invert(),(i=new m.Box3().setFromObject(r)).applyMatrix4(n),i);o.isEmpty()||t.push({min:o.min.clone(),max:o.max.clone()})}),t));if(!r.torso)return null;let n=new m.Vector3((r.torso.min.x+r.torso.max.x)*.5,(r.torso.min.y+r.torso.max.y)*.5,(r.torso.min.z+r.torso.max.z)*.5);e.updateMatrixWorld(!0);let i=e.matrixWorld.clone().invert(),o=null,a=1/0,s=new m.Vector3,l=new m.Box3;return e.traverse(e=>{if(!(e instanceof m.Mesh)||ef(e)||!e.geometry||(l.setFromObject(e),l.isEmpty()))return;l.applyMatrix4(i),l.getCenter(s);let t=s.distanceTo(n);t<a&&(a=t,o=e)}),o}(e);if(!r)return()=>{};e.updateMatrixWorld(!0),r.updateMatrixWorld(!0);let n=new m.Box3().setFromObject(r),i=n.getSize(new m.Vector3),o=n.getCenter(new m.Vector3),a=new m.Vector3(o.x,o.y+.015*i.y,n.max.z),s=.34*Math.min(i.x,i.y),l=new eu(r,a,new m.Euler(0,0,0),new m.Vector3(s,s,Math.max(.08,.28*i.z)));l.applyMatrix4(e.matrixWorld.clone().invert());let u=new m.Mesh(l,new m.MeshStandardMaterial({map:t,color:0xffffff,transparent:!0,alphaTest:.08,depthWrite:!1,roughness:.9,metalness:0,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));return u.userData.espBranding=!0,u.renderOrder=8,u.castShadow=!1,u.receiveShadow=!1,e.add(u),()=>{u.removeFromParent(),u.geometry.dispose(),u.material instanceof m.Material&&u.material.dispose()}}(e)},[e]),null}let eg="#e0a13a",ew="#242c37",eb="#161b23";function eS({size:e,position:t,color:r,chams:n,chamsColor:i="#4bd0e0",logo:o,children:a}){return(0,s.jsxs)("group",{position:t,children:[(0,s.jsxs)("mesh",{castShadow:!0,receiveShadow:!0,children:[(0,s.jsx)("boxGeometry",{args:e}),(0,s.jsx)("meshStandardMaterial",{color:r,roughness:.62,metalness:.06}),(0,s.jsx)(et,{scale:1.001,threshold:15,color:"#12161d"}),o?(0,s.jsx)(ex,{}):null]}),n?(0,s.jsxs)("mesh",{renderOrder:900,children:[(0,s.jsx)("boxGeometry",{args:e}),(0,s.jsx)("meshBasicMaterial",{color:i,transparent:!0,opacity:.35,depthTest:!0,depthWrite:!1,toneMapped:!1})]}):null,a]})}function eM({bodyRef:e,idle:t=!0,chams:r=!1,chamsColor:n,children:i}){let o=(0,l.useRef)(null);return(0,c.useFrame)(e=>{if(!o.current)return;let r=e.clock.elapsedTime,n=+!!t;o.current.position.y=.07*Math.sin(1.4*r)*n,o.current.rotation.z=.015*Math.sin(.7*r)*n,o.current.rotation.y=.05*Math.sin(.45*r)*n}),(0,s.jsxs)("group",{ref:o,children:[(0,s.jsxs)("group",{ref:e,children:[(0,s.jsxs)(eS,{size:[1.6,1.3,1.3],position:[0,1.65,0],color:eg,chams:r,chamsColor:n,children:[(0,s.jsxs)("mesh",{position:[-.34,.12,.66],children:[(0,s.jsx)("boxGeometry",{args:[.2,.26,.02]}),(0,s.jsx)("meshStandardMaterial",{color:eb,roughness:.4})]}),(0,s.jsxs)("mesh",{position:[.34,.12,.66],children:[(0,s.jsx)("boxGeometry",{args:[.2,.26,.02]}),(0,s.jsx)("meshStandardMaterial",{color:eb,roughness:.4})]}),(0,s.jsxs)("mesh",{position:[0,-.24,.66],children:[(0,s.jsx)("boxGeometry",{args:[.52,.09,.02]}),(0,s.jsx)("meshStandardMaterial",{color:eb,roughness:.4})]})]}),(0,s.jsx)(eS,{size:[2,2,1],position:[0,0,0],color:"#2f3947",chams:r,chamsColor:n,logo:!0}),(0,s.jsx)(eS,{size:[1,2,1],position:[-1.5,0,0],color:eg,chams:r,chamsColor:n}),(0,s.jsx)(eS,{size:[1,2,1],position:[1.5,0,0],color:eg,chams:r,chamsColor:n}),(0,s.jsx)(eS,{size:[1,2,1],position:[-.5,-2,0],color:ew,chams:r,chamsColor:n}),(0,s.jsx)(eS,{size:[1,2,1],position:[.5,-2,0],color:ew,chams:r,chamsColor:n})]}),i]})}let eE={current:null},eA="./preview-model/";function ez(e){let t,r,n;return!function(e){let t=[];e.traverse(e=>{e instanceof m.Mesh&&!ef(e)&&t.push(e)});let r=[];for(let e of t){if(ed(e.name))continue;let t=em(e),n=t.getSize(new m.Vector3);n.x<=2.6&&n.y<=11.5&&n.z<=2.6&&r.push(t)}let n=new m.Box3;r.forEach(e=>n.union(e)),n.isEmpty()&&n.setFromObject(e);let i=Math.max(.01,n.max.x-n.min.x),o=Math.max(.01,n.max.y-n.min.y),a=[];for(let e of t){if(ed(e.name)){a.push(e);continue}let t=em(e),r=t.getSize(new m.Vector3),s=t.getCenter(new m.Vector3),l=e.geometry.attributes.position?.count??0;if(function(e,t,r){let n=Math.max(1.25*t,3.2),i=Math.max(1.05*t,2.4);return!!(e.x>=n)||!!(e.z>=i)&&!!(e.z>.85*e.y)||!!(e.x>=.85*r)&&!!(e.x>1.4*e.y)}(r,i,o)){a.push(e);continue}let u=r.x<=2.2&&r.z<=2.2&&r.y<=2.2;if(l>1200&&!u){a.push(e);continue}s.y>n.min.y+.82*o&&l>350&&r.y>2*r.x&&a.push(e)}for(let e of a)e.parent?.remove(e),e.geometry?.dispose(),(Array.isArray(e.material)?e.material:[e.material]).forEach(e=>e?.dispose())}(e),r=(t=new m.Box3().setFromObject(e)).min.y,n=Math.max(.01,t.max.y-r),e.traverse(e=>{let t;if(!(e instanceof m.Mesh)||ef(e))return;let i=(t=(em(e).getCenter(new m.Vector3).y-r)/Math.max(.01,n))>.82?ep.skin.clone():t>.42?ep.shirt.clone():ep.pants.clone(),o=e.material,a=Array.isArray(o)?o:[o],s=a[0],l=s&&"map"in s&&s.map instanceof m.Texture?s.map:null,u=new m.MeshStandardMaterial({map:l,color:l?new m.Color(1.18,1.14,1.1):i,roughness:.52,metalness:.05,emissive:i.clone().multiplyScalar(l?.04:.08)});l&&(u.map.colorSpace=m.SRGBColorSpace,u.map.anisotropy=4),e.material=u,a.forEach(e=>e?.dispose())}),e}function eU(e){let t=new m.Group;t.add(e);let r=new m.Box3().setFromObject(e),n=r.getCenter(new m.Vector3),i=5.2/Math.max(.001,r.getSize(new m.Vector3).y);return t.scale.setScalar(i),t.position.set(-n.x*i,-r.min.y*i+-3,-n.z*i),t.traverse(e=>{e instanceof m.Mesh&&(e.castShadow=!0,e.receiveShadow=!0)}),t}function eD(e){e?.traverse(e=>{e instanceof m.Mesh&&(e.geometry?.dispose(),Array.isArray(e.material)?e.material.forEach(e=>e.dispose()):e.material?.dispose())})}function e_({bodyRef:e,idle:t=!0,chams:r=!1,chamsColor:n="#ff3355",children:i}){let o=(0,l.useRef)(null),[a,u]=(0,l.useState)(null),[f,d]=(0,l.useState)(null),p=(0,l.useRef)(""),[h]=(0,z.useHostValue)("preview.avatar_status","idle"),[v]=(0,z.useHostValue)("preview.avatar_user_id",""),[x]=(0,z.useHostValue)("preview.local_user_id",""),[y]=(0,z.useHostValue)("preview.avatar_base_url",""),[g]=(0,z.useHostValue)("preview.avatar_obj_url",""),[w]=(0,z.useHostValue)("preview.avatar_mtl_url",""),[b]=(0,z.useHostValue)("preview.avatar_tex_hashes",[]);(0,l.useEffect)(()=>{let e=!1;return new Promise((e,t)=>{let r=new A.MTLLoader;r.setPath(eA),r.load("avatar.mtl",r=>{r.preload();let n=new E.OBJLoader;n.setMaterials(r),n.load(`${eA}avatar.obj`,t=>e(eU(ez(t))),void 0,e=>t(e))},void 0,e=>t(e))}).then(t=>{e?eD(t):u(t)}).catch(()=>{e||u(null)}),()=>{e=!0}},[]),(0,l.useEffect)(()=>{if(x&&"loading"!==h){if("ready"===h&&g&&w&&v===x){p.current=x;return}(p.current!==x||"failed"!==h)&&(p.current=x,(0,z.callAction)("esp_preview_avatar"))}},[x,h,v,g,w]),(0,l.useEffect)(()=>{var e;if("ready"!==h||!y||!g||!w||x&&v!==x)return;let t=!1;return(e=b??[],new Promise((t,r)=>{let n=new A.MTLLoader;n.setPath(y),n.manager.setURLModifier(t=>{let r=t.split("/").pop()?.split("?")[0]??t;for(let n of e)if(t.includes(n)||r.includes(n))return`${y}${n}.png`;return t.startsWith("http://")||t.startsWith("https://")?t:y+t});let i=w.slice(y.length).split("?")[0]||"avatar.mtl",o=g.slice(y.length).split("?")[0]||"avatar.obj";n.load(i,e=>{e.preload();let n=new E.OBJLoader;n.setMaterials(e),n.load(o,e=>t(eU(ez(e))),void 0,e=>r(e))},void 0,e=>r(e))})).then(e=>{t?eD(e):d(t=>(eD(t),e))}).catch(()=>{}),()=>{t=!0}},[h,y,g,w,b,v,x]);let S=f??a;return((0,l.useEffect)(()=>{if(S&&r){let e;return e=[],S.traverse(t=>{if(!(t instanceof m.Mesh)||!t.geometry||t.userData.chamOverlay||t.userData.espBranding)return;let r=new m.MeshBasicMaterial({color:n,transparent:!0,opacity:.35,depthTest:!0,depthWrite:!1,toneMapped:!1}),i=new m.Mesh(t.geometry,r);i.renderOrder=900,i.userData.chamOverlay=!0,i.position.copy(t.position),i.rotation.copy(t.rotation),i.scale.copy(t.scale),t.parent?.add(i),e.push(i)}),()=>{e.forEach(e=>{e.removeFromParent(),e.material instanceof m.Material&&e.material.dispose()})}}},[S,r,n]),(0,c.useFrame)(e=>{if(!o.current||!t||!S)return;let r=e.clock.elapsedTime;o.current.position.y=.05*Math.sin(1.4*r)}),S||"failed"!==h)?S?(0,s.jsx)("group",{ref:e,children:(0,s.jsxs)("group",{ref:o,children:[(0,s.jsx)("primitive",{object:S}),(0,s.jsx)(ey,{target:S})]})}):(0,s.jsx)("group",{ref:e}):(0,s.jsx)("group",{ref:e,children:(0,s.jsx)(eM,{bodyRef:eE,idle:t,chams:r,chamsColor:n,children:i})})}function eC(e,t,r,n){t.makeEmpty(),e.updateMatrixWorld(!0),e.traverse(e=>{if(!(e instanceof m.Mesh)||!e.geometry||e.userData.chamOverlay||e.userData.espBranding)return;e.geometry.boundingBox||e.geometry.computeBoundingBox();let i=e.geometry.boundingBox;!i||i.isEmpty()||(r.copy(i).applyMatrix4(e.matrixWorld),r.getSize(n),n.x>2.35&&n.y<.6*n.x||n.z>2.2&&n.y<.7*n.z||t.union(r))})}function eB({bodyRef:e,hud:t}){let r=(0,f.useThree)(e=>e.camera),n=(0,f.useThree)(e=>e.size),i=(0,l.useMemo)(()=>new m.Box3,[]),o=(0,l.useMemo)(()=>new m.Box3,[]),a=(0,l.useMemo)(()=>new m.Vector3,[]),s=(0,l.useMemo)(()=>new m.Vector3,[]),u=(0,l.useMemo)(()=>new m.Vector3,[]);return(0,c.useFrame)(()=>{let l=e.current,c=t.current;if(!l||!c?.frame)return;if(eC(l,i,o,a),i.isEmpty()||!Number.isFinite(i.min.x)||i.max.y-i.min.y<.05){c.frame.style.opacity="0",c.tracer&&(c.tracer.style.opacity="0");return}i.getCenter(u);let f=1/0,d=1/0,m=-1/0,p=-1/0,h=!0;for(let e=0;e<8;e++){s.set(1&e?i.max.x:i.min.x,2&e?i.max.y:i.min.y,4&e?i.max.z:i.min.z),s.project(r),s.z>1&&(h=!1);let t=(.5*s.x+.5)*n.width,o=(-(.5*s.y)+.5)*n.height;f=Math.min(f,t),m=Math.max(m,t),d=Math.min(d,o),p=Math.max(p,o)}let v=m-f,x=p-d;c.frame.style.opacity=h?"1":"0",c.frame.style.transform=`translate3d(${f.toFixed(1)}px, ${d.toFixed(1)}px, 0)`,c.frame.style.width=`${v.toFixed(1)}px`,c.frame.style.height=`${x.toFixed(1)}px`,c.dist&&(c.dist.textContent=r.position.distanceTo(u).toFixed(1)),c.tracer&&(c.tracer.setAttribute("x2",(f+v/2).toFixed(1)),c.tracer.setAttribute("y2",p.toFixed(1)),c.tracer.style.opacity=h?"1":"0")}),null}function ej(e){let t=Math.max(.01,e.max.y-e.min.y),r=Math.max(.01,e.max.x-e.min.x),n=e.min.y+.015*t,i=e.max.y-.09*t,o=e.min.x+.18*r,a=e.max.x-.18*r,s=Math.max(.01,i-n),l=Math.max(.01,a-o),u=(o+a)*.5,c=(e.min.z+e.max.z)*.5,f=new m.Vector3(u,n+.91*s,c),d=new m.Vector3(u,n+.8*s,c),p=new m.Vector3(u,n+.47*s,c),h=new m.Vector3(u-.38*l,n+.77*s,c),v=new m.Vector3(u+.38*l,n+.77*s,c);return[[f,d],[d,p],[d,h],[h,new m.Vector3(u-.46*l,n+.46*s,c)],[d,v],[v,new m.Vector3(u+.46*l,n+.46*s,c)],[p,new m.Vector3(u-.16*l,n+.03*s,c)],[p,new m.Vector3(u+.16*l,n+.03*s,c)]]}function eP({bodyRef:e,enabled:t,color:r}){let n=(0,l.useMemo)(()=>new Float32Array(48),[]),i=(0,l.useMemo)(()=>{let e=new m.BufferGeometry;return e.setAttribute("position",new m.BufferAttribute(n,3)),e.setDrawRange(0,0),e},[n]),o=(0,l.useMemo)(()=>new m.Box3,[]),a=(0,l.useMemo)(()=>new m.Box3,[]),u=(0,l.useMemo)(()=>new m.Vector3,[]);return((0,c.useFrame)(()=>{let r=e.current;if(!t||!r||(eC(r,o,a,u),o.isEmpty()||o.max.y-o.min.y<.05))return void i.setDrawRange(0,0);let s=ej(o),l=0;for(let[e,t]of s)n[l++]=e.x,n[l++]=e.y,n[l++]=e.z,n[l++]=t.x,n[l++]=t.y,n[l++]=t.z;i.getAttribute("position").needsUpdate=!0,i.setDrawRange(0,2*s.length),i.computeBoundingSphere()}),t)?(0,s.jsx)("lineSegments",{geometry:i,frustumCulled:!1,renderOrder:2e3,children:(0,s.jsx)("lineBasicMaterial",{color:r,depthTest:!1,depthWrite:!1,transparent:!0,opacity:.95,toneMapped:!1})}):null}function eL({bodyRef:e,hud:t,enabled:r,headDot:n}){let i=(0,f.useThree)(e=>e.camera),o=(0,f.useThree)(e=>e.size),a=(0,l.useMemo)(()=>new m.Vector3,[]),s=(0,l.useMemo)(()=>new m.Box3,[]),u=(0,l.useMemo)(()=>new m.Box3,[]),d=(0,l.useMemo)(()=>new m.Vector3,[]);return(0,c.useFrame)(()=>{let l=t.current?.skeletonLines,c=t.current?.headDot,f=e.current;if(!f||!r&&!n||(eC(f,s,u,d),s.isEmpty())){l?.forEach(e=>{e&&(e.style.opacity="0")}),c&&(c.style.opacity="0");return}let m=ej(s);if(r&&l?.length)for(let e=0;e<l.length;e++){let t=l[e];if(!t)continue;if(e>=m.length){t.style.opacity="0";continue}let[r,n]=m[e],s=!0;a.copy(r),a.project(i),a.z>1&&(s=!1);let u=(.5*a.x+.5)*o.width,c=(-(.5*a.y)+.5)*o.height;a.copy(n),a.project(i),a.z>1&&(s=!1);let f=(.5*a.x+.5)*o.width,d=(-(.5*a.y)+.5)*o.height;t.setAttribute("x1",u.toFixed(1)),t.setAttribute("y1",c.toFixed(1)),t.setAttribute("x2",f.toFixed(1)),t.setAttribute("y2",d.toFixed(1)),t.setAttribute("stroke-opacity",s?"0.95":"0"),t.style.opacity=s?"1":"0"}else l?.forEach(e=>{e&&(e.style.opacity="0")});if(n&&c){let e=m[0][0];a.copy(e),a.project(i);let t=a.z<=1,r=(.5*a.x+.5)*o.width,n=(-(.5*a.y)+.5)*o.height;c.setAttribute("cx",r.toFixed(1)),c.setAttribute("cy",n.toFixed(1)),c.setAttribute("r","4"),c.style.opacity=t?"1":"0"}else c&&(c.style.opacity="0")}),null}function eV(){return(0,s.jsxs)("group",{children:[(0,s.jsx)(S,{position:[0,.01,0],args:[24,24],cellSize:1,cellThickness:.4,cellColor:"#243343",sectionSize:4,sectionThickness:.8,sectionColor:"#31586b",fadeDistance:22,fadeStrength:1.2,infiniteGrid:!0}),(0,s.jsxs)("mesh",{rotation:[-Math.PI/2,0,0],receiveShadow:!0,children:[(0,s.jsx)("planeGeometry",{args:[40,40]}),(0,s.jsx)("meshStandardMaterial",{color:"#161c25",roughness:.95,metalness:0})]})]})}e.s(["EspScene",0,function({options:e,hud:t}){let r=(0,l.useRef)(null);return(0,s.jsxs)(u.Canvas,{shadows:!0,dpr:[1,1.5],camera:{position:[5.8,3.8,6.8],fov:38},gl:{antialias:!0,alpha:!1},style:{width:"100%",height:"100%",display:"block"},children:[(0,s.jsx)("color",{attach:"background",args:["#14181f"]}),(0,s.jsx)("fog",{attach:"fog",args:["#14181f",18,42]}),(0,s.jsx)("ambientLight",{intensity:.5}),(0,s.jsx)("hemisphereLight",{args:["#8fd7e8","#0e1218",.45]}),(0,s.jsx)("directionalLight",{position:[5,9,4],intensity:1.4,castShadow:!0,"shadow-mapSize":[512,512],"shadow-camera-left":-10,"shadow-camera-right":10,"shadow-camera-top":10,"shadow-camera-bottom":-10}),(0,s.jsx)(eV,{}),(0,s.jsx)(v,{position:[0,.02,0],opacity:.38,scale:14,blur:2,far:6}),(0,s.jsx)("group",{position:[0,3,0],children:(0,s.jsx)(e_,{bodyRef:r,idle:e.idle,chams:e.chams,chamsColor:e.chamsColor})}),(0,s.jsx)(eB,{bodyRef:r,hud:t}),(0,s.jsx)(eP,{bodyRef:r,enabled:e.skeleton,color:e.skeletonColor}),(0,s.jsx)(eL,{bodyRef:r,hud:t,enabled:e.skeleton,headDot:e.headDot}),(0,s.jsx)(M.OrbitControls,{makeDefault:!0,target:[0,2.6,0],enablePan:!1,minDistance:4.8,maxDistance:11,minPolarAngle:.3,maxPolarAngle:Math.PI/2.05,enableDamping:!0,dampingFactor:.1,rotateSpeed:.65})]})}],13515)},94513,function(e){e.n(e.i(13515))}]);