﻿mcp/ - LuaVM bridge for Cursor and OpenCode

  gain-luavm.mjs   MCP server script (Node.js)

Connect from the LuaVM panel in Gain (Cursor / OpenCode buttons).
Requires Node.js on PATH. Gain must be running with LuaVM available.
